using UnityEngine;

namespace UIToolkitExamples
{
    public class PlanetScript : MonoBehaviour
    {
        public Temperature coreTemperature;
    }
}