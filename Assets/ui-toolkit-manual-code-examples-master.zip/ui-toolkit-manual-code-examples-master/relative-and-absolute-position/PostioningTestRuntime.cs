using UnityEngine;
using UnityEngine.UIElements;

public class PostioningTestRuntime : MonoBehaviour
{
    void OnEnable()
    {
        GetComponent<UIDocument>();

    }   
}

        

