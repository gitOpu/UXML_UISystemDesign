using System;

[Serializable]
public struct GameSwitch
{
    public string name;
    public bool enabled;
}